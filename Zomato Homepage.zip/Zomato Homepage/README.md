# Zomato-cloned-website
 Cloned zomato website using html and css for study purpose
